-- Roteiro de conferência no phpMyAdmin, após importar instalar_banco.sql.
-- Use dados de teste e tire prints DEPOIS de executar cada parte.
USE mini_sistema;
-- Figura A: estrutura e índices (aba SQL ou Estrutura do phpMyAdmin)
SHOW TABLES;
DESCRIBE usuarios;
DESCRIBE clientes;
SHOW INDEX FROM clientes;
-- Figura B: cadastro via tela do sistema e persistência (abra Procurar na tabela clientes)
SELECT ID, NOME, EMAIL, TELEFONE, CRIADO_POR, CRIADO_EM
FROM clientes ORDER BY ID DESC;
-- Figura C: edição - altere um cliente pela tela e repita SELECT filtrando o ID
-- Substitua 123 pelo ID REAL do cliente de teste, sem colar o literal nas provas.
-- SELECT ID, NOME, EMAIL, TELEFONE FROM clientes WHERE ID = 123;
-- Figura D: exclusão - exclua o cliente de teste pela tela e repita o SELECT do ID
-- Resultado esperado: zero linhas (não exclua registros reais).
-- SELECT ID, NOME, EMAIL, TELEFONE FROM clientes WHERE ID = 123;
