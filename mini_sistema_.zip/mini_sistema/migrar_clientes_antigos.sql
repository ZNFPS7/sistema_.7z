-- Execute APENAS se já havia clientes gravados na tabela usuarios antiga.
-- 1) FAÇA BACKUP da base mini_sistema antes de usar.
-- 2) Importe instalar_banco.sql primeiro.
-- 3) Revise quais contas representam clientes: a regra abaixo exclui SOMENTE
--    admin@sistema.com. Ajuste o filtro se você possui mais usuários de login.
-- 4) O script COPIA os registros; não apaga nenhuma conta anterior.
USE mini_sistema;
INSERT INTO clientes (NOME, EMAIL, TELEFONE, CRIADO_POR, CRIADO_EM)
SELECT u.NOME, u.EMAIL, u.TELEFONE, admin.ID, u.CRIADO_EM
FROM usuarios AS u
JOIN usuarios AS admin ON admin.EMAIL = 'admin@sistema.com'
WHERE u.EMAIL <> 'admin@sistema.com'
  AND NOT EXISTS (
    SELECT 1 FROM clientes AS c WHERE c.EMAIL = u.EMAIL
  );
