<?php
declare(strict_types=1);

require_once 'auth.php';
require_once 'conexao.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
$mensagem = '';
$tipo_mensagem = '';
$cliente = null;
$excluido_com_sucesso = false;

$cliente_id = 0;
$cliente_nome = '';
$cliente_email = '';

// 1. Busca o cliente para exibir os dados no aviso
if ($id > 0) {
    $stmt = $pdo->prepare('SELECT ID, NOME, EMAIL FROM clientes WHERE ID = ?');
    $stmt->execute([$id]);
    $cliente = $stmt->fetch();

    if ($cliente) {
        $cliente_id = (int)$cliente['ID'];
        $cliente_nome = (string)$cliente['NOME'];
        $cliente_email = (string)$cliente['EMAIL'];
    }
}

if (!$cliente) {
    $mensagem = 'Cliente com ID #' . $id . ' não foi encontrado!';
    $tipo_mensagem = 'error';
    header('Refresh: 2; url=clientes.php');
} 
// 2. Só executa a exclusão se o formulário for enviado com a senha (POST)
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha_informada = trim($_POST['senha_confirmacao'] ?? '');

    if (empty($senha_informada)) {
        $mensagem = 'A senha é obrigatória para confirmar a exclusão!';
        $tipo_mensagem = 'error';
    } else {
        $stmtAuth = $pdo->prepare('SELECT SENHA FROM usuarios WHERE ID = ?');
        $stmtAuth->execute([$_SESSION['usuario_id']]);
        $usuario_logado = $stmtAuth->fetch();

        if ($usuario_logado && password_verify($senha_informada, $usuario_logado['SENHA'])) {
            $delete = $pdo->prepare('DELETE FROM clientes WHERE ID = ?');
            $delete->execute([$cliente_id]);

            $excluido_com_sucesso = true;
            $mensagem = 'Cliente "' . $cliente_nome . '" removido permanentemente!';
            $tipo_mensagem = 'success';

            header('Refresh: 2; url=clientes.php');
        } else {
            $mensagem = 'Senha incorreta! A exclusão foi cancelada.';
            $tipo_mensagem = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar Exclusão - CRM</title>
    <link rel="stylesheet" href="css/styly.css">
    <style>
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(6, 9, 17, 0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            padding: 20px;
            animation: fadeInUp 0.3s ease forwards;
        }
        .modal-box {
            background: rgba(15, 23, 42, 0.96);
            border: 1px solid rgba(239, 68, 68, 0.5);
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.8), 0 0 35px rgba(239, 68, 68, 0.2);
            border-radius: 20px;
            max-width: 480px;
            width: 100%;
            padding: 34px 30px;
            text-align: center;
        }
        .modal-icon {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 16px;
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.25);
        }
        .modal-title {
            font-size: 1.45rem;
            font-weight: 700;
            color: #f8fafc;
            margin-bottom: 10px;
        }
        .modal-warning {
            background: rgba(239, 68, 68, 0.12);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
            padding: 12px 16px;
            border-radius: 10px;
            font-size: 0.9rem;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        .modal-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            margin-top: 22px;
        }
        .modal-actions .btn {
            flex: 1;
            padding: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="header-top">
                <h1><span class="brand-mark">CRM</span> Gestão de Clientes</h1>
                <div class="user-bar">
                    <span class="user-name">👤 <?php echo htmlspecialchars((string)$_SESSION['usuario_nome']); ?></span>
                    <a href="logout.php" class="btn btn-secondary btn-sm">🚪 Sair</a>
                </div>
            </div>
            <nav>
                <a href="index.php" class="nav-link">Home</a>
                <a href="cadastro.php" class="nav-link">Cadastrar Cliente</a>
                <a href="clientes.php" class="nav-link active">Listar Clientes</a>
            </nav>
        </header>

        <main>
            <div class="modal-overlay">
                <div class="modal-box">
                    <?php if ($cliente && !$excluido_com_sucesso): ?>
                        <div class="modal-icon">⚠️</div>
                        <h2 class="modal-title">Ação Irreversível!</h2>

                        <div class="modal-warning">
                            Esta ação <strong>não pode ser desfeita</strong>.<br>
                            Está prestes a excluir permanentemente o cliente:<br>
                            <strong style="color: #fff; font-size: 1rem;"><?php echo htmlspecialchars($cliente_nome); ?></strong>
                            (ID #<?php echo $cliente_id; ?>)
                        </div>

                        <?php if (!empty($mensagem)): ?>
                            <div class="alert alert-<?php echo $tipo_mensagem; ?>" style="text-align: left;">
                                <?php echo htmlspecialchars($mensagem); ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="apagar.php?id=<?php echo $cliente_id; ?>" style="text-align: left;">
                            <input type="hidden" name="id" value="<?php echo $cliente_id; ?>">

                            <div class="form-group" style="margin-bottom: 10px;">
                                <label for="senha_confirmacao">🔐 Digite a sua senha de login para confirmar</label>
                                <input 
                                    type="password" 
                                    id="senha_confirmacao" 
                                    name="senha_confirmacao" 
                                    placeholder="A sua senha de administrador" 
                                    required 
                                    autofocus
                                >
                            </div>

                            <div class="modal-actions">
                                <a href="clientes.php" class="btn btn-secondary">✖️ Cancelar</a>
                                <button type="submit" class="btn btn-danger">🗑️ Confirmar Exclusão</button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="modal-icon"><?php echo $excluido_com_sucesso ? '✅' : '❌'; ?></div>
                        <h2 class="modal-title"><?php echo $excluido_com_sucesso ? 'Cliente Excluído' : 'Aviso'; ?></h2>
                        <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                            <?php echo htmlspecialchars($mensagem); ?>
                        </div>
                        <p style="color: var(--text-muted); font-size: 0.88rem; margin-bottom: 16px;">
                            A redirecionar para a lista de clientes...
                        </p>
                        <a href="clientes.php" class="btn btn-primary" style="width: 100%;">📋 Voltar para Lista</a>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>