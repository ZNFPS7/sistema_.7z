<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
?>
<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sistema de Gerenciamento de Clientes</title>
    <link rel="stylesheet" href="css/styly.css" />
  </head>
  <body>
    <div class="container">
      <header>
        <div class="header-top">
          <h1><span class="brand-mark">CRM</span> Gestão de Clientes</h1>
          <div class="user-bar">
            <span class="user-name">👤 <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
            <a href="logout.php" class="btn btn-secondary btn-sm">🚪 Sair</a>
          </div>
        </div>
        <nav>
          <a href="index.php" class="nav-link active">Home</a>
          <a href="cadastro.php" class="nav-link">Cadastrar Cliente</a>
          <a href="clientes.php" class="nav-link">Listar Clientes</a>
        </nav>
      </header>

      <main>
        <section class="welcome">
          <div class="welcome-content">
            <!-- Logo Minimalista e Futurista em Vetor/CSS -->
            <div class="futuristic-logo-box">
              <div class="logo-hexagon">
                <svg viewBox="0 0 100 100" width="64" height="64" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <polygon points="50,5 93,28 93,72 50,95 7,72 7,28" stroke="url(#cyanGrad)" stroke-width="3.5" fill="rgba(6, 182, 212, 0.08)"/>
                  <circle cx="50" cy="40" r="12" stroke="#22d3ee" stroke-width="3"/>
                  <path d="M28 74C28 62 38 56 50 56C62 56 72 62 72 74" stroke="#38bdf8" stroke-width="3" stroke-linecap="round"/>
                  <defs>
                    <linearGradient id="cyanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stop-color="#22d3ee" />
                      <stop offset="100%" stop-color="#3b82f6" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
              <div class="logo-typography">
                <span class="logo-main-text">Sistema de gerenciamento</span>
                <span class="logo-sub-text">de clientes</span>
              </div>
            </div>

            <h2></h2>
            <p>
              
            </p>
            <div class="actions">
              <a href="cadastro.php" class="btn btn-primary">➕ Novo Cliente</a>
              <a href="clientes.php" class="btn btn-secondary">👥 Ver Clientes</a>
            </div>
          </div>
        </section>

        <section class="features">
          <h3>Funcionalidades</h3>
          <div class="features-grid">
            <a href="cadastro.php" class="feature-card">
              <span class="feature-icon">➕</span>
              <h4>Cadastrar</h4>
              <p>Adicione novos clientes ao sistema</p>
            </a>
            <a href="clientes.php" class="feature-card">
              <span class="feature-icon">📋</span>
              <h4>Listar</h4>
              <p>Visualize todos os clientes cadastrados</p>
            </a>
            <a href="clientes.php" class="feature-card">
              <span class="feature-icon">✏️</span>
              <h4>Atualizar</h4>
              <p>Modifique informações dos clientes</p>
            </a>
            <a href="clientes.php" class="feature-card">
              <span class="feature-icon">🗑️</span>
              <h4>Apagar</h4>
              <p>Remova clientes do sistema</p>
            </a>
          </div>
        </section>
      </main>

      <footer>
        <p>
          &copy; 2026 Sistema de Gerenciamento de Clientes. Todos os direitos
          reservados.
        </p>
      </footer>
    </div>
  </body>
</html>