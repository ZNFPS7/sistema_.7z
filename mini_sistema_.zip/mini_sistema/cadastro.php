<?php
require_once 'auth.php';
require_once 'conexao.php';

// Processar formulário
$mensagem = '';
$tipo_mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');

    if (strlen($nome) < 3 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Informe um nome com pelo menos 3 caracteres e um email válido!';
        $tipo_mensagem = 'error';
    } else {
        try {
            $stmt = $pdo->prepare('INSERT INTO clientes (NOME, EMAIL, TELEFONE, CRIADO_POR) VALUES (?, ?, ?, ?)');
            $stmt->execute([$nome, $email, $telefone === '' ? null : $telefone, (int)$_SESSION['usuario_id']]);
            $mensagem = 'Cliente cadastrado com sucesso!';
            $tipo_mensagem = 'success';
        } catch (PDOException $e) {
            // Código 23000 (1062) indica violação de chave única (e-mail duplicado)
            if ($e->getCode() === '23000') {
                $mensagem = "O email '{$email}' já está cadastrado no sistema! Por favor, utilize outro.";
                $tipo_mensagem = 'error';
            } else {
                $mensagem = 'Ocorreu um erro ao cadastrar o cliente. Tente novamente.';
                $tipo_mensagem = 'error';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Cliente</title>
    <link rel="stylesheet" href="css/styly.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-top">
                <h1><span class="brand-mark">CRM</span> Gestão de Clientes</h1>
                <div class="user-bar">
                    <span class="user-name">👤 <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                    <a href="logout.php" class="btn btn-secondary btn-sm">🚪 Sair</a>
                </div>
            </div>
            <nav>
                <a href="index.php" class="nav-link">Home</a>
                <a href="cadastro.php" class="nav-link active">Cadastrar Cliente</a>
                <a href="clientes.php" class="nav-link">Listar Clientes</a>
            </nav>
        </header>

        <main>
            <div class="form-container">
                <h2>➕ Cadastrar Novo Cliente</h2>

                <?php if (!empty($mensagem)): ?>
                    <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                        <?php echo htmlspecialchars($mensagem); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" id="formCadastro">
                    <div class="form-group">
                        <label for="nome">Nome Completo *</label>
                        <input 
                            type="text" 
                            id="nome" 
                            name="nome" 
                            placeholder="Digite o nome completo" 
                            required
                        >
                        <small class="field-help">Informe nome e sobrenome, com pelo menos 3 caracteres.</small>
                    </div>

                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            placeholder="Digite o email" 
                            required
                        >
                        <small class="field-help">Usaremos este email para identificar o cadastro.</small>
                    </div>

                    <div class="form-group">
                        <label for="telefone">Telefone</label>
                        <input 
                            type="tel" 
                            id="telefone" 
                            name="telefone" 
                            placeholder="(11) 99999-9999"
                            inputmode="numeric"
                            autocomplete="tel"
                        >
                        <small class="field-help">Opcional. Digite apenas números; a formatação será aplicada automaticamente.</small>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">💾 Cadastrar Cliente</button>
                        <a href="clientes.php" class="btn btn-secondary">📋 Ver Clientes</a>
                    </div>
                </form>
            </div>
        </main>

        <footer>
            <p>&copy; 2026 Sistema de Gerenciamento de Clientes. Todos os direitos reservados.</p>
        </footer>
    </div>

    <script src="js/cadastro.js"></script>
</body>
</html>