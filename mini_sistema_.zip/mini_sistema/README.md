# Sistema de Gestão de Clientes — versão corrigida

CRUD em PHP, HTML, CSS e JavaScript, com banco MySQL/MariaDB via PDO e login por sessão.
A aparência das páginas foi mantida. A correção separa **usuários que fazem login** de
**clientes cadastrados**, resolvendo a incompatibilidade entre cadastro sem senha e
`usuarios.SENHA NOT NULL`.

## Instalação no XAMPP (Windows)

1. Inicie **Apache** e **MySQL** no painel do XAMPP.
2. Copie a pasta `mini_sistema` para `C:\xampp\htdocs\mini_sistema`.
3. Abra `http://localhost/phpmyadmin` (se Apache usa 8080, `http://localhost:8080/phpmyadmin`).
4. Na aba **SQL** da página inicial, importe `instalar_banco.sql`.
   O script cria o banco `mini_sistema`, as tabelas `usuarios` e `clientes` e o login demo.
5. Abra `http://localhost/mini_sistema/login.php` (ou com a porta 8080).
6. Demonstração: `admin@sistema.com` / `admin123`. **Troque a senha em ambiente real**.

Caso o sistema tenha sido executado antes da correção, faça **backup** do banco e
importe `instalar_banco.sql`. Se os clientes antigos estavam na tabela `usuarios`,
**revise** `migrar_clientes_antigos.sql` antes de executá-lo: ele copia todas as
contas diferentes de `admin@sistema.com` para clientes, sem apagar as contas.

## Modelagem

- `usuarios`: ID (PK), NOME, EMAIL (UNIQUE), TELEFONE, SENHA (hash), CRIADO_EM.
- `clientes`: ID (PK), NOME, EMAIL (UNIQUE), TELEFONE, CRIADO_POR (FK), CRIADO_EM.
- Um usuário pode cadastrar muitos clientes (**1:N**) usando `clientes.CRIADO_POR`.
- Não existe relacionamento N:N implementado nesta versão.

## Código e segurança

- `login.php` autentica na tabela `usuarios` via `password_verify`.
- `cadastro.php`, `clientes.php`, `atualizar.php` e `apagar.php` trabalham com `clientes`.
- `apagar.php` confirma a senha do **usuário logado** em `usuarios`, preservando
  a verificação de segurança independentemente do ID do cliente.
- E-mails únicos e FK são verificados pelo banco. Nome mínimo e e-mail válido são
  validados no back-end. Os comandos INSERT/UPDATE/DELETE usam prepared statements.

## Prints para o relatório

O arquivo `roteiro_evidencias.sql` contém os comandos de inspeção. Capture na sua
instalação do phpMyAdmin: `usuarios` e `clientes` (Estrutura), `clientes` (Procurar)
e as consultas após cadastrar, editar e excluir um registro fictício pela interface.
Os dados de uma instalação local não podem ser comprovados por imagens fabricadas.

## Links

- Repositório público identificado no histórico do pacote: https://github.com/Furlani18/Mini_Sistema
- **Importante:** este repositório público possui outras funcionalidades e não foi
  automaticamente atualizado com as correções contidas neste ZIP. Para comprovar
  esta versão, publique-a no repositório da equipe antes de entregar.
- Deploy e vídeo não constavam do material fornecido.
