-- Script legado mantido para compatibilidade documental.
-- Para a versão corrigida, importe instalar_banco.sql, que cria usuarios e clientes
-- com as chaves e relacionamento necessários.
-- Este arquivo preserva APENAS a definição de contas de acesso.
CREATE DATABASE IF NOT EXISTS mini_sistema CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mini_sistema;
CREATE TABLE IF NOT EXISTS usuarios (
  ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NOME VARCHAR(100) NOT NULL,
  EMAIL VARCHAR(100) NOT NULL UNIQUE,
  TELEFONE VARCHAR(20) NULL,
  SENHA VARCHAR(255) NOT NULL,
  CRIADO_EM TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO usuarios (NOME, EMAIL, TELEFONE, SENHA)
SELECT 'Administrador', 'admin@sistema.com', '(11) 99999-9999',
       '$2y$10$WwIGamvh.3DWV.SUUaHQh.P6tHWdjhNBdOh1pLUB0DZe8DA1GE5d6'
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE EMAIL = 'admin@sistema.com');
